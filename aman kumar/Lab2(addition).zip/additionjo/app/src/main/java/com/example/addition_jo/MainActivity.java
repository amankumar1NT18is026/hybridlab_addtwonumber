package com.example.addition_jo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
     EditText n1;
     EditText n2;
     Button button;
     TextView res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        n1=findViewById(R.id.num1);
        n2=findViewById(R.id.num2);
        button=findViewById(R.id.button);
        res=findViewById(R.id.Result);
      button.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              int r=Integer.parseInt(n1.getText().toString())+Integer.parseInt(n2.getText().toString());
              res.setText("Result is:"+r);
          }
      });
    }
    protected void onStart(){
        super.onStart();
       //Log.i("stage1","onstart() started");  super.onStart();
        Toast.makeText(getApplicationContext(), "Onstart started", Toast.LENGTH_SHORT).show();//onStart Called

    }
}