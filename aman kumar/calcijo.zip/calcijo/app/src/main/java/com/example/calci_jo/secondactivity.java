package com.example.calci_jo;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class secondactivity extends AppCompatActivity {
    TextView res;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondactivity);

        num=Integer.valueOf(getIntent().getStringExtra("result"));
        res=(TextView)findViewById(R.id.res1);
        res.setText(String.valueOf(num));
    }
}