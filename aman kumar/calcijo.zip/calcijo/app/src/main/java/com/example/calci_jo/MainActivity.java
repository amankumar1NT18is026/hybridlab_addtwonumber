package com.example.calci_jo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  EditText n1,n2;
  Button btn;
  Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1=(EditText)findViewById(R.id.num1);
        n2=(EditText)findViewById(R.id.num2);
        btn=(Button)findViewById(R.id.res);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int r=Integer.parseInt(n1.getText().toString())+Integer.parseInt(n2.getText().toString());
                intent=new Intent(MainActivity.this,secondactivity.class);
                intent.putExtra("result",""+r);
                startActivity(intent);
            }
        });
    }
}